import * as Location from 'expo-location';
import { getDistance } from 'geolib';

class LocationService {
  // Obtenir l'adresse à partir des coordonnées
  static async getAddressFromCoordinates(latitude, longitude) {
    try {
      const addressResponse = await Location.reverseGeocodeAsync({
        latitude,
        longitude
      });

      if (addressResponse && addressResponse.length > 0) {
        const address = addressResponse[0];
        return {
          formattedAddress: `${address.street || ''} ${address.name || ''}, ${address.city || ''}, ${address.region || ''}`,
          city: address.city || '',
          country: address.country || '',
          street: address.street || address.name || '',
          postalCode: address.postalCode || '',
          district: address.district || '',
        };
      }
      return null;
    } catch (error) {
      console.error('Erreur lors de la conversion des coordonnées en adresse:', error);
      return null;
    }
  }

  // Calculer la distance entre deux points en kilomètres
  static calculateDistance(startLat, startLng, endLat, endLng) {
    try {
      const distanceInMeters = getDistance(
        { latitude: startLat, longitude: startLng },
        { latitude: endLat, longitude: endLng }
      );
      
      // Convertir en kilomètres et arrondir à 1 décimale
      return Math.round((distanceInMeters / 1000) * 10) / 10;
    } catch (error) {
      console.error('Erreur lors du calcul de la distance:', error);
      return 0;
    }
  }

  // Estimer le temps de trajet en minutes (approximation simple)
  static estimateTravelTime(distanceKm) {
    // Vitesse moyenne estimée à 30 km/h dans les villes maliennes
    const averageSpeedKmh = 30;
    
    // Temps en heures = distance / vitesse
    const timeHours = distanceKm / averageSpeedKmh;
    
    // Convertir en minutes et ajouter un temps fixe pour le démarrage
    const startupTimeMinutes = 3;
    const totalMinutes = Math.round((timeHours * 60) + startupTimeMinutes);
    
    return Math.max(5, totalMinutes); // Minimum 5 minutes
  }

  // Trouver les chauffeurs à proximité (simulation)
  static findNearbyDrivers(latitude, longitude, radius = 5000) {
    // Simulation de chauffeurs à proximité
    // Dans une application réelle, cela serait connecté à une base de données
    const randomDrivers = [];
    const numberOfDrivers = Math.floor(Math.random() * 5) + 2; // 2 à 6 chauffeurs
    
    for (let i = 0; i < numberOfDrivers; i++) {
      // Générer des positions aléatoires dans un rayon de 'radius' mètres
      const randomDistance = Math.random() * radius;
      const randomAngle = Math.random() * 2 * Math.PI;
      
      // Conversion approximative de mètres en degrés (varie selon la latitude)
      const latOffset = randomDistance * Math.cos(randomAngle) / 111000;
      const lngOffset = randomDistance * Math.sin(randomAngle) / (111000 * Math.cos(latitude * Math.PI / 180));
      
      randomDrivers.push({
        id: `driver-${i + 1}`,
        name: `Chauffeur ${i + 1}`,
        rating: (3 + Math.random() * 2).toFixed(1), // Note entre 3 et 5
        coordinate: {
          latitude: latitude + latOffset,
          longitude: longitude + lngOffset
        },
        vehicle: {
          type: Math.random() > 0.7 ? 'moto' : 'standard',
          model: Math.random() > 0.5 ? 'Toyota Corolla' : 'Peugeot 307',
          color: ['Blanc', 'Noir', 'Gris', 'Bleu'][Math.floor(Math.random() * 4)]
        }
      });
    }
    
    return randomDrivers;
  }
}

export default LocationService;
