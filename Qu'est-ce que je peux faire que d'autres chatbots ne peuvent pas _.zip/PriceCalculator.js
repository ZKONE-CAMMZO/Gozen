import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { PRICING } from '../../utils/constants';

const PriceCalculator = ({ distance, duration, vehicleType = 'standard' }) => {
  const [price, setPrice] = useState(0);

  useEffect(() => {
    const calculatePrice = () => {
      const baseFare = PRICING.BASE_FARE;
      const distanceCost = distance * PRICING.PRICE_PER_KM;
      const durationCost = duration * PRICING.PRICE_PER_MINUTE;
      
      let totalPrice = baseFare + distanceCost + durationCost;
      
      // Appliquer le prix minimum si nécessaire
      if (totalPrice < PRICING.MINIMUM_FARE) {
        totalPrice = PRICING.MINIMUM_FARE;
      }
      
      // Modifier le prix selon le type de véhicule
      if (vehicleType === 'moto') {
        totalPrice = totalPrice * 0.8; // 20% moins cher pour les motos
      } else if (vehicleType === 'premium') {
        totalPrice = totalPrice * 1.5; // 50% plus cher pour les véhicules premium
      }
      
      // Ajouter la commission de l'application
      const commission = totalPrice * PRICING.APP_COMMISSION;
      totalPrice += commission;
      
      // Arrondir à la dizaine supérieure pour simplifier
      totalPrice = Math.ceil(totalPrice / 10) * 10;
      
      setPrice(totalPrice);
    };
    
    calculatePrice();
  }, [distance, duration, vehicleType]);

  return (
    <View style={styles.container}>
      <View style={styles.priceRow}>
        <Text style={styles.priceLabel}>Prix estimé:</Text>
        <Text style={styles.priceValue}>{price} FCFA</Text>
      </View>
      <Text style={styles.priceDetails}>
        Inclut: prix de base ({PRICING.BASE_FARE} FCFA) + distance ({distance} km) + durée ({duration} min)
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginVertical: 10,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  priceLabel: {
    fontSize: 16,
    color: '#333',
  },
  priceValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  priceDetails: {
    fontSize: 12,
    color: '#666',
  },
});

export default PriceCalculator;
