import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, TextInput, Alert } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { APP_PARAMS } from '../../utils/constants';
import useLocation from '../../hooks/useLocation';
import LocationService from '../../services/LocationService';

const MapScreen = ({ navigation }) => {
  const { location, errorMsg, loading, updateLocation } = useLocation();
  const [region, setRegion] = useState(APP_PARAMS.DEFAULT_REGION);
  const [destination, setDestination] = useState('');
  const [currentLocation, setCurrentLocation] = useState('Ma position actuelle');
  const [nearbyDrivers, setNearbyDrivers] = useState([]);
  const [currentAddress, setCurrentAddress] = useState('');

  // Mettre à jour la région et l'adresse lorsque la localisation change
  useEffect(() => {
    if (location) {
      const newRegion = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.0122,
        longitudeDelta: 0.0121,
      };
      setRegion(newRegion);
      
      // Obtenir l'adresse actuelle
      const getAddress = async () => {
        const address = await LocationService.getAddressFromCoordinates(
          location.coords.latitude,
          location.coords.longitude
        );
        if (address) {
          setCurrentAddress(address.formattedAddress);
          setCurrentLocation(address.formattedAddress);
        }
      };
      
      getAddress();
      
      // Trouver les chauffeurs à proximité
      const drivers = LocationService.findNearbyDrivers(
        location.coords.latitude,
        location.coords.longitude
      );
      setNearbyDrivers(drivers);
    }
  }, [location]);

  // Gérer les erreurs de localisation
  useEffect(() => {
    if (errorMsg) {
      Alert.alert(
        "Erreur de localisation",
        errorMsg,
        [{ text: "OK" }]
      );
    }
  }, [errorMsg]);

  const handleBookRide = () => {
    if (destination) {
      // Dans une application réelle, nous calculerions l'itinéraire ici
      // Pour le prototype, nous simulons une distance et une durée
      const simulatedDistance = 5.2; // km
      const simulatedDuration = 18; // minutes
      
      navigation.navigate('Booking', { 
        origin: currentLocation,
        destination: destination,
        region: region,
        distance: simulatedDistance,
        duration: simulatedDuration
      });
    } else {
      Alert.alert(
        "Destination manquante",
        "Veuillez entrer une destination",
        [{ text: "OK" }]
      );
    }
  };

  const handleRefreshLocation = () => {
    updateLocation();
  };

  return (
    <View style={styles.container}>
      <MapView
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        region={region}
        onRegionChangeComplete={setRegion}
        showsUserLocation={true}
        showsMyLocationButton={true}
      >
        {/* Marqueur pour la position actuelle */}
        <Marker
          coordinate={{
            latitude: region.latitude,
            longitude: region.longitude,
          }}
          title="Ma position"
          description={currentAddress}
          pinColor="#FF6B00"
        />

        {/* Marqueurs pour les chauffeurs à proximité */}
        {nearbyDrivers.map(driver => (
          <Marker
            key={driver.id}
            coordinate={driver.coordinate}
            title={driver.name}
            description={`${driver.vehicle.model} ${driver.vehicle.color}`}
            pinColor="#4285F4"
          />
        ))}
      </MapView>

      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Text style={styles.searchLabel}>Départ</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Ma position actuelle"
            value={currentLocation}
            editable={false}
          />
        </View>
        <View style={styles.searchBox}>
          <Text style={styles.searchLabel}>Destination</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Où allez-vous?"
            value={destination}
            onChangeText={setDestination}
          />
        </View>
      </View>

      <View style={styles.bottomContainer}>
        <TouchableOpacity 
          style={styles.bookButton}
          onPress={handleBookRide}
        >
          <Text style={styles.bookButtonText}>RÉSERVER MAINTENANT</Text>
        </TouchableOpacity>
      </View>

      {loading && (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Localisation en cours...</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  map: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
  searchContainer: {
    position: 'absolute',
    top: 40,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    margin: 20,
    padding: 15,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  searchBox: {
    marginBottom: 10,
  },
  searchLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 3,
  },
  searchInput: {
    fontSize: 16,
    color: '#333',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 8,
  },
  bottomContainer: {
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  bookButton: {
    backgroundColor: '#FF6B00',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 30,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  bookButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.7)',
    padding: 10,
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    fontSize: 14,
  },
});

export default MapScreen;
