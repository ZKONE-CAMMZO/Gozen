import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// Écrans d'authentification
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';

// Écrans principaux
import MapScreen from '../screens/map/MapScreen';
import BookingScreen from '../screens/booking/BookingScreen';
import BookingConfirmationScreen from '../screens/booking/BookingConfirmationScreen';
import RideTrackingScreen from '../screens/booking/RideTrackingScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Navigateur pour les écrans d'authentification
const AuthNavigator = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Login" component={LoginScreen} />
    <Stack.Screen name="Register" component={RegisterScreen} />
  </Stack.Navigator>
);

// Navigateur pour les écrans de réservation
const BookingNavigator = () => (
  <Stack.Navigator>
    <Stack.Screen name="Booking" component={BookingScreen} options={{ title: 'Réservation' }} />
    <Stack.Screen name="BookingConfirmation" component={BookingConfirmationScreen} options={{ title: 'Confirmation' }} />
    <Stack.Screen name="RideTracking" component={RideTrackingScreen} options={{ title: 'Suivi du trajet' }} />
  </Stack.Navigator>
);

// Navigateur principal avec tabs
const MainNavigator = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName;
        if (route.name === 'Map') {
          iconName = focused ? 'map' : 'map-outline';
        } else if (route.name === 'BookingTab') {
          iconName = focused ? 'car' : 'car-outline';
        }
        return <Ionicons name={iconName} size={size} color={color} />;
      },
      tabBarActiveTintColor: '#FF6B00',
      tabBarInactiveTintColor: 'gray',
    })}
  >
    <Tab.Screen 
      name="Map" 
      component={MapScreen} 
      options={{ 
        headerShown: false,
        title: 'Carte'
      }} 
    />
    <Tab.Screen 
      name="BookingTab" 
      component={BookingNavigator} 
      options={{ 
        headerShown: false,
        title: 'Réserver'
      }} 
    />
  </Tab.Navigator>
);

// Navigateur racine de l'application
const AppNavigator = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Auth" component={AuthNavigator} />
    <Stack.Screen name="Main" component={MainNavigator} />
  </Stack.Navigator>
);

export default AppNavigator;
