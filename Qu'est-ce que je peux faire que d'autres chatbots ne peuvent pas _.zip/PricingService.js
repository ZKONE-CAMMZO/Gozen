import { PRICING } from '../utils/constants';

class PricingService {
  /**
   * Calcule le prix d'une course en fonction de la distance et de la durée
   * @param {number} distanceKm - Distance en kilomètres
   * @param {number} durationMin - Durée en minutes
   * @param {string} vehicleType - Type de véhicule ('standard', 'moto', 'premium')
   * @returns {Object} Détails du prix calculé
   */
  static calculatePrice(distanceKm, durationMin, vehicleType = 'standard') {
    // Prix de base
    const baseFare = PRICING.BASE_FARE;
    
    // Coût lié à la distance
    const distanceCost = distanceKm * PRICING.PRICE_PER_KM;
    
    // Coût lié à la durée
    const durationCost = durationMin * PRICING.PRICE_PER_MINUTE;
    
    // Prix avant ajustements
    let subtotal = baseFare + distanceCost + durationCost;
    
    // Appliquer le prix minimum si nécessaire
    if (subtotal < PRICING.MINIMUM_FARE) {
      subtotal = PRICING.MINIMUM_FARE;
    }
    
    // Ajustement selon le type de véhicule
    let vehicleMultiplier = 1;
    if (vehicleType === 'moto') {
      vehicleMultiplier = 0.8; // 20% moins cher pour les motos
    } else if (vehicleType === 'premium') {
      vehicleMultiplier = 1.5; // 50% plus cher pour les véhicules premium
    }
    
    subtotal = subtotal * vehicleMultiplier;
    
    // Calcul de la commission de l'application
    const commission = subtotal * PRICING.APP_COMMISSION;
    
    // Prix total incluant la commission
    let totalPrice = subtotal + commission;
    
    // Arrondir à la dizaine supérieure pour simplifier
    totalPrice = Math.ceil(totalPrice / 10) * 10;
    
    // Retourner les détails du prix
    return {
      baseFare,
      distanceCost,
      durationCost,
      subtotal: Math.round(subtotal),
      commission: Math.round(commission),
      totalPrice: Math.round(totalPrice),
      currency: 'FCFA'
    };
  }

  /**
   * Estime la consommation de carburant pour une course
   * @param {number} distanceKm - Distance en kilomètres
   * @param {string} vehicleType - Type de véhicule
   * @returns {Object} Détails de la consommation estimée
   */
  static estimateFuelConsumption(distanceKm, vehicleType = 'standard') {
    // Consommation moyenne en litres/100km selon le type de véhicule
    let consumptionPer100Km;
    
    switch (vehicleType) {
      case 'moto':
        consumptionPer100Km = 3; // 3L/100km pour les motos
        break;
      case 'premium':
        consumptionPer100Km = 12; // 12L/100km pour les véhicules premium
        break;
      case 'standard':
      default:
        consumptionPer100Km = 8; // 8L/100km pour les véhicules standard
        break;
    }
    
    // Calcul de la consommation pour la distance donnée
    const fuelLiters = (distanceKm * consumptionPer100Km) / 100;
    
    // Coût du carburant
    const fuelCost = fuelLiters * PRICING.FUEL_PRICE_PER_LITER;
    
    return {
      fuelLiters: Math.round(fuelLiters * 10) / 10, // Arrondi à 1 décimale
      fuelCost: Math.round(fuelCost),
      fuelPricePerLiter: PRICING.FUEL_PRICE_PER_LITER,
      currency: 'FCFA'
    };
  }

  /**
   * Calcule le gain du chauffeur pour une course
   * @param {number} totalPrice - Prix total de la course
   * @returns {Object} Détails du gain du chauffeur
   */
  static calculateDriverEarnings(totalPrice) {
    // Le chauffeur reçoit le prix total moins la commission
    const commission = totalPrice * PRICING.APP_COMMISSION;
    const driverEarnings = totalPrice - commission;
    
    return {
      totalPrice,
      commission: Math.round(commission),
      driverEarnings: Math.round(driverEarnings),
      commissionRate: PRICING.APP_COMMISSION * 100 + '%',
      currency: 'FCFA'
    };
  }
}

export default PricingService;
