// Création d'une icône simple pour l'application Gozen
const canvas = document.createElement('canvas');
canvas.width = 1024;
canvas.height = 1024;
const ctx = canvas.getContext('2d');

// Fond orange
ctx.fillStyle = '#FF6B00';
ctx.fillRect(0, 0, 1024, 1024);

// Cercle blanc
ctx.fillStyle = '#FFFFFF';
ctx.beginPath();
ctx.arc(512, 512, 400, 0, 2 * Math.PI);
ctx.fill();

// Lettre G stylisée
ctx.fillStyle = '#FF6B00';
ctx.font = 'bold 600px Arial';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillText('G', 512, 512);

// Exporter l'image
const dataURL = canvas.toDataURL('image/png');
const img = new Image();
img.src = dataURL;
document.body.appendChild(img);

// Pour télécharger l'image
const a = document.createElement('a');
a.href = dataURL;
a.download = 'gozen-icon.png';
a.click();
