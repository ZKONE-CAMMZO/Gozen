module.exports = {
  build: {
    android: {
      buildType: "apk"
    }
  },
  android: {
    package: "com.gozen.mobile"
  },
  ios: {
    bundleIdentifier: "com.gozen.mobile"
  }
};
