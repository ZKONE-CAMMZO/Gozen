// Constants pour l'application Gozen

// Paramètres de tarification
export const PRICING = {
  BASE_FARE: 500, // Prix de base en FCFA
  PRICE_PER_KM: 200, // Prix par kilomètre en FCFA
  PRICE_PER_MINUTE: 50, // Prix par minute en FCFA
  FUEL_PRICE_PER_LITER: 750, // Prix de l'essence au Mali (FCFA/litre)
  APP_COMMISSION: 0.10, // Commission de l'application (10%)
  MINIMUM_FARE: 1000, // Prix minimum pour une course en FCFA
};

// Paramètres de l'application
export const APP_PARAMS = {
  DEFAULT_REGION: {
    latitude: 12.6392, // Coordonnées de Bamako, Mali
    longitude: -8.0029,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  },
  DRIVER_SEARCH_RADIUS: 5000, // Rayon de recherche des chauffeurs en mètres
  MAX_WAITING_TIME: 15, // Temps d'attente maximum en minutes
};

// Types de véhicules
export const VEHICLE_TYPES = {
  STANDARD: 'standard',
  PREMIUM: 'premium',
  MOTO: 'moto',
};

// Statuts de réservation
export const BOOKING_STATUS = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
};

// Méthodes de paiement
export const PAYMENT_METHODS = {
  CASH: 'cash',
  ORANGE_MONEY: 'orange_money',
  MOOV_MONEY: 'moov_money',
};
