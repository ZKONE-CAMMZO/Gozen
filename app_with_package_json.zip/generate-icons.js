const fs = require('fs');
const { createCanvas } = require('canvas');

// Fonction pour créer une icône simple
function createIcon(size, outputPath, backgroundColor, textColor) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');

  // Fond
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, size, size);

  // Cercle blanc
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(size/2, size/2, size*0.4, 0, 2 * Math.PI);
  ctx.fill();

  // Lettre G stylisée
  ctx.fillStyle = textColor;
  ctx.font = `bold ${size*0.6}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('G', size/2, size/2);

  // Enregistrer l'image
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(outputPath, buffer);
  console.log(`Icône créée: ${outputPath}`);
}

// Créer les différentes icônes nécessaires
try {
  createIcon(1024, './assets/icon.png', '#FF6B00', '#FF6B00');
  createIcon(1024, './assets/adaptive-icon.png', '#FF6B00', '#FF6B00');
  createIcon(512, './assets/favicon.png', '#FF6B00', '#FF6B00');
  
  // Créer une image splash
  const splashSize = 1242;
  const splashCanvas = createCanvas(splashSize, splashSize);
  const splashCtx = splashCanvas.getContext('2d');
  
  // Fond orange
  splashCtx.fillStyle = '#FF6B00';
  splashCtx.fillRect(0, 0, splashSize, splashSize);
  
  // Logo blanc
  splashCtx.fillStyle = '#FFFFFF';
  splashCtx.font = 'bold 120px Arial';
  splashCtx.textAlign = 'center';
  splashCtx.textBaseline = 'middle';
  splashCtx.fillText('GOZEN', splashSize/2, splashSize/2 - 60);
  
  // Tagline
  splashCtx.font = '40px Arial';
  splashCtx.fillText('Votre transport au Mali', splashSize/2, splashSize/2 + 60);
  
  // Enregistrer l'image splash
  const splashBuffer = splashCanvas.toBuffer('image/png');
  fs.writeFileSync('./assets/splash.png', splashBuffer);
  console.log('Image splash créée: ./assets/splash.png');
  
  console.log('Toutes les icônes ont été générées avec succès!');
} catch (error) {
  console.error('Erreur lors de la création des icônes:', error);
}
