import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import PricingService from '../../services/PricingService';
import { PRICING } from '../../utils/constants';

const BookingScreen = ({ route, navigation }) => {
  const { origin, destination, region, distance = 5.2, duration = 18 } = route.params || {};
  const [selectedVehicle, setSelectedVehicle] = useState('standard');
  const [priceDetails, setPriceDetails] = useState(null);
  const [fuelConsumption, setFuelConsumption] = useState(null);

  // Calcul du prix basé sur la distance et la durée
  useEffect(() => {
    const calculatePriceDetails = () => {
      const details = PricingService.calculatePrice(distance, duration, selectedVehicle);
      setPriceDetails(details);
      
      const fuel = PricingService.estimateFuelConsumption(distance, selectedVehicle);
      setFuelConsumption(fuel);
    };
    
    calculatePriceDetails();
  }, [distance, duration, selectedVehicle]);

  const handleConfirmBooking = () => {
    // Naviguer vers l'écran de confirmation avec les détails de la réservation
    navigation.navigate('BookingConfirmation', {
      origin,
      destination,
      distance,
      duration,
      priceDetails,
      vehicleType: selectedVehicle
    });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.headerText}>Détails de la course</Text>
      </View>

      <View style={styles.routeContainer}>
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, styles.originMarker]} />
          <Text style={styles.routeText}>{origin || 'Ma position actuelle'}</Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, styles.destinationMarker]} />
          <Text style={styles.routeText}>{destination || 'Destination'}</Text>
        </View>
      </View>

      <View style={styles.infoContainer}>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Distance</Text>
          <Text style={styles.infoValue}>{distance} km</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Durée estimée</Text>
          <Text style={styles.infoValue}>{duration} min</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Prix</Text>
          <Text style={styles.infoValue}>{priceDetails?.totalPrice || 0} FCFA</Text>
        </View>
      </View>

      {priceDetails && (
        <View style={styles.priceDetailsContainer}>
          <Text style={styles.sectionTitle}>Détails du prix</Text>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Prix de base</Text>
            <Text style={styles.priceValue}>{priceDetails.baseFare} FCFA</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Distance ({distance} km)</Text>
            <Text style={styles.priceValue}>{priceDetails.distanceCost} FCFA</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Durée ({duration} min)</Text>
            <Text style={styles.priceValue}>{priceDetails.durationCost} FCFA</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Sous-total</Text>
            <Text style={styles.priceValue}>{priceDetails.subtotal} FCFA</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Commission (10%)</Text>
            <Text style={styles.priceValue}>{priceDetails.commission} FCFA</Text>
          </View>
          <View style={[styles.priceRow, styles.totalRow]}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>{priceDetails.totalPrice} FCFA</Text>
          </View>
        </View>
      )}

      {fuelConsumption && (
        <View style={styles.fuelContainer}>
          <Text style={styles.sectionSubtitle}>Consommation estimée</Text>
          <Text style={styles.fuelText}>
            {fuelConsumption.fuelLiters} litres ({fuelConsumption.fuelCost} FCFA)
          </Text>
        </View>
      )}

      <View style={styles.vehicleContainer}>
        <Text style={styles.sectionTitle}>Type de véhicule</Text>
        <View style={styles.vehicleOptions}>
          <TouchableOpacity 
            style={[
              styles.vehicleOption, 
              selectedVehicle === 'standard' && styles.vehicleOptionSelected
            ]}
            onPress={() => setSelectedVehicle('standard')}
          >
            <Text style={styles.vehicleOptionText}>Standard</Text>
            <Text style={styles.vehicleOptionPrice}>
              {priceDetails?.totalPrice || 0} FCFA
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.vehicleOption, 
              selectedVehicle === 'moto' && styles.vehicleOptionSelected
            ]}
            onPress={() => setSelectedVehicle('moto')}
          >
            <Text style={styles.vehicleOptionText}>Moto</Text>
            <Text style={styles.vehicleOptionPrice}>
              {priceDetails ? Math.round(priceDetails.totalPrice * 0.8) : 0} FCFA
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.paymentContainer}>
        <Text style={styles.sectionTitle}>Méthode de paiement</Text>
        <View style={styles.paymentOption}>
          <Text style={styles.paymentOptionText}>Paiement en espèces</Text>
        </View>
      </View>

      <TouchableOpacity 
        style={styles.confirmButton}
        onPress={handleConfirmBooking}
      >
        <Text style={styles.confirmButtonText}>CONFIRMER LA RÉSERVATION</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  headerContainer: {
    marginTop: 20,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  routeContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  routeMarker: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  originMarker: {
    backgroundColor: '#4CAF50',
  },
  destinationMarker: {
    backgroundColor: '#FF6B00',
  },
  routeLine: {
    width: 2,
    height: 20,
    backgroundColor: '#ddd',
    marginLeft: 5,
  },
  routeText: {
    fontSize: 16,
    color: '#333',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  infoItem: {
    alignItems: 'center',
  },
  infoLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  priceDetailsContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  priceLabel: {
    fontSize: 14,
    color: '#666',
  },
  priceValue: {
    fontSize: 14,
    color: '#333',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    marginTop: 5,
    paddingTop: 10,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  fuelContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  sectionSubtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  fuelText: {
    fontSize: 14,
    color: '#666',
  },
  vehicleContainer: {
    marginBottom: 20,
  },
  vehicleOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  vehicleOption: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  vehicleOptionSelected: {
    backgroundColor: '#FFF0E6',
    borderWidth: 1,
    borderColor: '#FF6B00',
  },
  vehicleOptionText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  vehicleOptionPrice: {
    fontSize: 14,
    color: '#666',
  },
  paymentContainer: {
    marginBottom: 30,
  },
  paymentOption: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
  },
  paymentOptionText: {
    fontSize: 16,
    color: '#333',
  },
  confirmButton: {
    backgroundColor: '#FF6B00',
    borderRadius: 8,
    padding: 15,
    alignItems: 'center',
    marginBottom: 30,
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default BookingScreen;
