import { useState, useEffect } from 'react';
import * as Location from 'expo-location';

export const useLocation = () => {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        
        // Demander la permission d'accéder à la localisation
        let { status } = await Location.requestForegroundPermissionsAsync();
        
        if (status !== 'granted') {
          setErrorMsg('La permission d\'accéder à la localisation a été refusée');
          setLoading(false);
          return;
        }

        // Obtenir la position actuelle
        let currentLocation = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Highest,
          maximumAge: 10000
        });
        
        setLocation(currentLocation);
      } catch (error) {
        setErrorMsg('Impossible d\'obtenir la localisation: ' + error.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Fonction pour mettre à jour la localisation
  const updateLocation = async () => {
    try {
      setLoading(true);
      let currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Highest
      });
      setLocation(currentLocation);
      setLoading(false);
    } catch (error) {
      setErrorMsg('Impossible de mettre à jour la localisation: ' + error.message);
      setLoading(false);
    }
  };

  return { location, errorMsg, loading, updateLocation };
};

export default useLocation;
