import { registerRootComponent } from 'expo';
import App from './src/App';

// Enregistre le composant racine de l'application
registerRootComponent(App);
