import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import PricingService from '../../services/PricingService';
import LocationService from '../../services/LocationService';

const BookingConfirmationScreen = ({ route, navigation }) => {
  const { 
    origin, 
    destination, 
    distance, 
    duration, 
    priceDetails,
    vehicleType 
  } = route.params || {};
  
  const [driver, setDriver] = useState(null);
  const [estimatedArrival, setEstimatedArrival] = useState(null);
  const [bookingStatus, setBookingStatus] = useState('searching');

  useEffect(() => {
    // Simuler la recherche d'un chauffeur
    const searchDriver = async () => {
      setBookingStatus('searching');
      
      // Attendre 3 secondes pour simuler la recherche
      setTimeout(() => {
        // Générer un chauffeur aléatoire
        const nearbyDrivers = LocationService.findNearbyDrivers(12.6392, -8.0029);
        if (nearbyDrivers.length > 0) {
          const selectedDriver = nearbyDrivers[0];
          setDriver(selectedDriver);
          
          // Calculer le temps d'arrivée estimé (3-8 minutes)
          const arrivalTime = Math.floor(Math.random() * 5) + 3;
          setEstimatedArrival(arrivalTime);
          
          setBookingStatus('confirmed');
        } else {
          setBookingStatus('failed');
          Alert.alert(
            "Aucun chauffeur disponible",
            "Désolé, aucun chauffeur n'est disponible pour le moment. Veuillez réessayer plus tard.",
            [{ text: "OK", onPress: () => navigation.navigate('Map') }]
          );
        }
      }, 3000);
    };
    
    searchDriver();
  }, []);

  const handleCancelBooking = () => {
    Alert.alert(
      "Annuler la réservation",
      "Êtes-vous sûr de vouloir annuler cette réservation ?",
      [
        { text: "Non", style: "cancel" },
        { 
          text: "Oui", 
          onPress: () => {
            setBookingStatus('cancelled');
            navigation.navigate('Map');
          }
        }
      ]
    );
  };

  const handleContactDriver = () => {
    Alert.alert(
      "Contacter le chauffeur",
      `Appeler ${driver?.name} au +223 76 XX XX XX ?`,
      [
        { text: "Annuler", style: "cancel" },
        { text: "Appeler" }
      ]
    );
  };
  
  const handleStartRide = () => {
    navigation.navigate('RideTracking', {
      driver,
      origin,
      destination,
      estimatedArrival
    });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.headerText}>
          {bookingStatus === 'searching' ? 'Recherche de chauffeur...' : 
           bookingStatus === 'confirmed' ? 'Chauffeur confirmé' : 
           'Réservation'}
        </Text>
      </View>

      {bookingStatus === 'searching' && (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Recherche du chauffeur le plus proche...</Text>
          <Text style={styles.loadingSubtext}>Cela peut prendre quelques instants</Text>
        </View>
      )}

      {bookingStatus === 'confirmed' && driver && (
        <View style={styles.driverContainer}>
          <View style={styles.driverHeader}>
            <Text style={styles.driverName}>{driver.name}</Text>
            <Text style={styles.driverRating}>★ {driver.rating}</Text>
          </View>
          
          <View style={styles.driverInfo}>
            <Text style={styles.vehicleInfo}>
              {driver.vehicle.model} • {driver.vehicle.color}
            </Text>
            <Text style={styles.arrivalInfo}>
              Arrivée dans environ {estimatedArrival} minutes
            </Text>
          </View>
          
          <TouchableOpacity 
            style={styles.contactButton}
            onPress={handleContactDriver}
          >
            <Text style={styles.contactButtonText}>CONTACTER LE CHAUFFEUR</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.contactButton, styles.startRideButton]}
            onPress={handleStartRide}
          >
            <Text style={styles.contactButtonText}>SUIVRE LE TRAJET</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.routeContainer}>
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, styles.originMarker]} />
          <Text style={styles.routeText}>{origin || 'Ma position actuelle'}</Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, styles.destinationMarker]} />
          <Text style={styles.routeText}>{destination || 'Destination'}</Text>
        </View>
      </View>

      <View style={styles.infoContainer}>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Distance</Text>
          <Text style={styles.infoValue}>{distance} km</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Durée estimée</Text>
          <Text style={styles.infoValue}>{duration} min</Text>
        </View>
        <View style={styles.infoItem}>
          <Text style={styles.infoLabel}>Prix</Text>
          <Text style={styles.infoValue}>{priceDetails?.totalPrice || 0} FCFA</Text>
        </View>
      </View>

      <View style={styles.paymentContainer}>
        <Text style={styles.sectionTitle}>Méthode de paiement</Text>
        <View style={styles.paymentOption}>
          <Text style={styles.paymentOptionText}>Paiement en espèces</Text>
        </View>
      </View>

      {bookingStatus === 'confirmed' && (
        <TouchableOpacity 
          style={styles.cancelButton}
          onPress={handleCancelBooking}
        >
          <Text style={styles.cancelButtonText}>ANNULER LA RÉSERVATION</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  headerContainer: {
    marginTop: 20,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  loadingContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  loadingText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  loadingSubtext: {
    fontSize: 14,
    color: '#666',
  },
  driverContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  driverHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  driverName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  driverRating: {
    fontSize: 16,
    color: '#FF6B00',
    fontWeight: 'bold',
  },
  driverInfo: {
    marginBottom: 15,
  },
  vehicleInfo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  arrivalInfo: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  contactButton: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#FF6B00',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  contactButtonText: {
    color: '#FF6B00',
    fontSize: 14,
    fontWeight: 'bold',
  },
  routeContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  routeMarker: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  originMarker: {
    backgroundColor: '#4CAF50',
  },
  destinationMarker: {
    backgroundColor: '#FF6B00',
  },
  routeLine: {
    width: 2,
    height: 20,
    backgroundColor: '#ddd',
    marginLeft: 5,
  },
  routeText: {
    fontSize: 16,
    color: '#333',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
  },
  infoItem: {
    alignItems: 'center',
  },
  infoLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  paymentContainer: {
    marginBottom: 30,
  },
  paymentOption: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
  },
  paymentOptionText: {
    fontSize: 16,
    color: '#333',
  },
  cancelButton: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#FF3B30',
    borderRadius: 8,
    padding: 15,
    alignItems: 'center',
    marginBottom: 30,
  },
  cancelButtonText: {
    color: '#FF3B30',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default BookingConfirmationScreen;
