import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { APP_PARAMS } from '../../utils/constants';

const RideTrackingScreen = ({ route, navigation }) => {
  const { driver, origin, destination, estimatedArrival } = route.params || {};
  const [region, setRegion] = useState(APP_PARAMS.DEFAULT_REGION);
  const [driverLocation, setDriverLocation] = useState(driver?.coordinate || null);
  const [remainingTime, setRemainingTime] = useState(estimatedArrival || 5);
  const [rideStatus, setRideStatus] = useState('en_route'); // en_route, arrived, in_progress, completed

  // Simuler le mouvement du chauffeur
  useEffect(() => {
    if (driverLocation && rideStatus === 'en_route') {
      const interval = setInterval(() => {
        // Déplacer le chauffeur vers la destination (simulation)
        const newLat = driverLocation.latitude + (region.latitude - driverLocation.latitude) * 0.1;
        const newLng = driverLocation.longitude + (region.longitude - driverLocation.longitude) * 0.1;
        
        setDriverLocation({
          latitude: newLat,
          longitude: newLng
        });
        
        // Mettre à jour le temps restant
        setRemainingTime(prev => {
          const newTime = prev - 0.5;
          if (newTime <= 0) {
            clearInterval(interval);
            setRideStatus('arrived');
            return 0;
          }
          return newTime;
        });
      }, 3000);
      
      return () => clearInterval(interval);
    }
  }, [driverLocation, rideStatus]);

  // Simuler le début et la fin du trajet
  useEffect(() => {
    if (rideStatus === 'arrived') {
      // Attendre 5 secondes puis commencer le trajet
      const timer = setTimeout(() => {
        setRideStatus('in_progress');
        // Simuler un trajet de 10 secondes
        setTimeout(() => {
          setRideStatus('completed');
        }, 10000);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [rideStatus]);

  const getStatusText = () => {
    switch (rideStatus) {
      case 'en_route':
        return `Chauffeur en route - Arrivée dans ${Math.ceil(remainingTime)} min`;
      case 'arrived':
        return 'Chauffeur arrivé - Préparez-vous à embarquer';
      case 'in_progress':
        return 'En route vers votre destination';
      case 'completed':
        return 'Trajet terminé - Merci d\'avoir utilisé Gozen!';
      default:
        return '';
    }
  };

  const handleEndRide = () => {
    navigation.navigate('Map');
  };

  return (
    <View style={styles.container}>
      <MapView
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        region={region}
        onRegionChangeComplete={setRegion}
      >
        {/* Marqueur pour la position actuelle */}
        <Marker
          coordinate={{
            latitude: region.latitude,
            longitude: region.longitude,
          }}
          title="Ma position"
          pinColor="#FF6B00"
        />

        {/* Marqueur pour le chauffeur */}
        {driverLocation && (
          <Marker
            coordinate={driverLocation}
            title={driver?.name || "Chauffeur"}
            description={driver?.vehicle?.model || ""}
            pinColor="#4285F4"
          />
        )}

        {/* Ligne entre le chauffeur et l'utilisateur */}
        {driverLocation && (
          <Polyline
            coordinates={[
              driverLocation,
              { latitude: region.latitude, longitude: region.longitude }
            ]}
            strokeColor="#4285F4"
            strokeWidth={3}
            lineDashPattern={[1, 3]}
          />
        )}
      </MapView>

      <View style={styles.statusContainer}>
        <Text style={styles.statusText}>{getStatusText()}</Text>
        
        {rideStatus === 'en_route' && (
          <View style={styles.driverInfo}>
            <Text style={styles.driverName}>{driver?.name || "Chauffeur"}</Text>
            <Text style={styles.vehicleInfo}>
              {driver?.vehicle?.model || "Véhicule"} • {driver?.vehicle?.color || ""}
            </Text>
          </View>
        )}
        
        {rideStatus === 'completed' && (
          <TouchableOpacity 
            style={styles.endRideButton}
            onPress={handleEndRide}
          >
            <Text style={styles.endRideButtonText}>TERMINER</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  map: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
  statusContainer: {
    position: 'absolute',
    bottom: 30,
    left: 20,
    right: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statusText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  driverInfo: {
    marginTop: 10,
  },
  driverName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  vehicleInfo: {
    fontSize: 14,
    color: '#666',
  },
  endRideButton: {
    backgroundColor: '#FF6B00',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    marginTop: 15,
  },
  endRideButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default RideTrackingScreen;
