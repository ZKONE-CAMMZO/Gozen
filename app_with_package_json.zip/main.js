// Navigation mobile
const navSlide = () => {
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.nav-links');
  const navLinks = document.querySelectorAll('.nav-links li');
  
  burger.addEventListener('click', () => {
    // Toggle Nav
    nav.classList.toggle('nav-active');
    
    // Animate Links
    navLinks.forEach((link, index) => {
      if (link.style.animation) {
        link.style.animation = '';
      } else {
        link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0.3}s`;
      }
    });
    
    // Burger Animation
    burger.classList.toggle('toggle');
  });
}

// Smooth scrolling for anchor links
const smoothScroll = () => {
  const links = document.querySelectorAll('a[href^="#"]');
  
  for (const link of links) {
    link.addEventListener('click', clickHandler);
  }
  
  function clickHandler(e) {
    e.preventDefault();
    const href = this.getAttribute('href');
    const offsetTop = document.querySelector(href).offsetTop - 80;
    
    scroll({
      top: offsetTop,
      behavior: 'smooth'
    });
    
    // Close mobile menu if open
    const nav = document.querySelector('.nav-links');
    const burger = document.querySelector('.burger');
    if (nav.classList.contains('nav-active')) {
      nav.classList.remove('nav-active');
      burger.classList.remove('toggle');
    }
  }
}

// Sticky header on scroll
const stickyHeader = () => {
  const header = document.querySelector('header');
  const hero = document.querySelector('.hero');
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
      header.style.background = 'rgba(255, 255, 255, 0.95)';
    } else {
      header.style.boxShadow = 'none';
      header.style.background = 'var(--white-color)';
    }
  });
}

// Form submission
const handleFormSubmission = () => {
  const form = document.querySelector('.contact-form');
  
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Simulate form submission
      const submitButton = form.querySelector('button[type="submit"]');
      const originalText = submitButton.textContent;
      
      submitButton.textContent = 'Envoi en cours...';
      submitButton.disabled = true;
      
      setTimeout(() => {
        form.reset();
        submitButton.textContent = 'Envoyé !';
        
        setTimeout(() => {
          submitButton.textContent = originalText;
          submitButton.disabled = false;
        }, 2000);
      }, 1500);
    });
  }
}

// Initialize all functions
document.addEventListener('DOMContentLoaded', () => {
  navSlide();
  smoothScroll();
  stickyHeader();
  handleFormSubmission();
});
